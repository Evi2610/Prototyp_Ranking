package de.bs.tu.buyuk.ba.ranking.question;

public enum EnumLoopParameter {
i,j,k;
}
