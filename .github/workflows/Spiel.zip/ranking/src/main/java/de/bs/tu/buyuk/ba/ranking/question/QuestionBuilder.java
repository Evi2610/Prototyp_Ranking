package de.bs.tu.buyuk.ba.ranking.question;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class QuestionBuilder {

	private static QuestionBuilder INSTANCE = null;

	private QuestionBuilder() {

	}

	public static QuestionBuilder getINSTANCE() {
		if (INSTANCE != null) {
			return INSTANCE;
		}
		INSTANCE = new QuestionBuilder();
		return INSTANCE;
	}

	public void buildQuestion(Question question) {
		List<StackObject> operationStack = new ArrayList<>();
		createOuterParameters(question);
		createHead(question);
		createOperation(question, operationStack);
		for (int i = 0; i < question.getLevel() / 3; i++) {
			createOperation(question, operationStack);
		}
		solve(question.getSteps(), operationStack, question);
		Random ran = new Random();
		int abcd = ran.nextInt(4);

		List<Integer> wrongOptions = new ArrayList<>(10);
		wrongOptions.add(question.getResult() + 1);
		wrongOptions.add(question.getResult() + 2);
		wrongOptions.add(question.getResult() - 1);
		wrongOptions.add(question.getResult() - 2);
		wrongOptions.add(question.getResult() / 2);
		wrongOptions.add(question.getResult() * 2);
		wrongOptions.add(question.getResult() * -1);
		wrongOptions.add(question.getResult() * -2);
		wrongOptions.add(question.getResult() / -1);
		wrongOptions.add(question.getResult() / -2);
		Collections.shuffle(wrongOptions);

		question.setPossibleAnswers(new HashMap<>());
		switch (abcd) {
		case 0:
			question.getPossibleAnswers().put("A", question.getResult());
			question.setCorrectAnswer("A");
			break;
		case 1:
			question.getPossibleAnswers().put("B", question.getResult());
			question.setCorrectAnswer("B");
			break;
		case 2:
			question.getPossibleAnswers().put("C", question.getResult());
			question.setCorrectAnswer("C");
			break;
		case 3:
			question.getPossibleAnswers().put("D", question.getResult());
			question.setCorrectAnswer("D");
			break;
		}
		int wrong = 0;
		if (!question.getPossibleAnswers().containsKey("A")) {
			while (wrongOptions.get(wrong).equals(question.getResult())) {
				wrong++;
			}
			question.getPossibleAnswers().put("A", wrongOptions.get(wrong++));
		}
		if (!question.getPossibleAnswers().containsKey("B")) {
			while (wrongOptions.get(wrong).equals(question.getResult())) {
				wrong++;
			}
			question.getPossibleAnswers().put("B", wrongOptions.get(wrong++));
		}
		if (!question.getPossibleAnswers().containsKey("C")) {
			while (wrongOptions.get(wrong).equals(question.getResult())) {
				wrong++;
			}
			question.getPossibleAnswers().put("C", wrongOptions.get(wrong++));
		}
		if (!question.getPossibleAnswers().containsKey("D")) {
			while (wrongOptions.get(wrong).equals(question.getResult())) {
				wrong++;
			}
			question.getPossibleAnswers().put("D", wrongOptions.get(wrong++));
		}
	}

	private void createOuterParameters(Question question) {
		Random ran = new Random();
		List<EnumParameterName> outerParametersNames = new ArrayList<>();
		List<Integer> outerParametersValues = new ArrayList<>();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < question.getLevel() / 5 + 1; i++) {
			EnumParameterName parameterName = EnumParameterName.values()[i];
			outerParametersNames.add(parameterName);
			sb.append("int ");
			sb.append(parameterName.toString());
			sb.append(" = ");
			Integer parameterValue = ran.nextInt(question.getLevel() * question.getLevel() / 10 + 1);
			outerParametersValues.add(parameterValue);
			sb.append(parameterValue);
			sb.append(";\n");
		}
		sb.append("\n");
		question.setQuestionText(sb.toString());
		question.setOuterParametersNames(outerParametersNames);
		question.setOuterParametersValues(outerParametersValues);
	}

	private void createHead(Question question) {
		Random ran = new Random();
		StringBuilder sb = new StringBuilder();
		sb.append(question.getQuestionText());
		boolean equals = ran.nextBoolean();
		EnumLoopParameter loopParameter = EnumLoopParameter.values()[ran.nextInt(EnumLoopParameter.values().length)];
		sb.append("for( int ");
		sb.append(loopParameter);
		sb.append(" = 0; ");
		sb.append(loopParameter);
		int steps = ran.nextInt((10 + 1) * question.getLevel());
		if (equals) {
			sb.append(" <= ");
		} else {
			sb.append(" < ");
		}
		question.setSteps(steps);
		sb.append(question.getSteps());
		if (equals) {
			question.setSteps(steps + 1);
		}
		sb.append("; ");
		sb.append(loopParameter);
		sb.append("++) {\n");
		question.setQuestionText(sb.toString());

	}

	private void createOperation(Question question, List<StackObject> operationStack) {
		StringBuilder sb = new StringBuilder();
		sb.append(question.getQuestionText());
		sb.append("	");
		Random ran = new Random();

		EnumOperation enumOperation = EnumOperation.values()[ran.nextInt(EnumOperation.values().length)];
		int number = ran.nextInt(question.getLevel()) + 1;
		int a = ran.nextInt(question.getOuterParametersNames().size());
		int b = ran.nextInt(question.getOuterParametersNames().size());
		operationStack.add(new StackObject(a, enumOperation, b, number));
		switch (enumOperation) {
		case ADD:
		case SUBSTRACT:
		case MULTIPLY:
		case DIVIDE:
		case MODULO:
			sb.append(question.getOuterParametersNames().get(a));
			sb.append(" = ");
			sb.append(question.getOuterParametersNames().get(b));
			sb.append(enumOperation.getDisplayLabel());
			sb.append(number);
			break;
		case PREINCREMENT:
		case PREDECREMENT:
			sb.append(enumOperation.getDisplayLabel());
			sb.append(question.getOuterParametersNames().get(b));
			break;
		case POSTINCREMENT:
		case POSTDECREMENT:
			sb.append(question.getOuterParametersNames().get(b));
			sb.append(enumOperation.getDisplayLabel());
			break;
		}
		sb.append(";\n");
		question.setQuestionText(sb.toString());
	}

	public void solve(int steps, List<StackObject> stack, Question question) {
		for (int i = 0; i < steps; i++) {
			for (StackObject so : stack) {
				switch (so.operation) {
				case ADD:
					question.getOuterParameters().set(so.indexA,
							question.getOuterParameters().get(so.indexB) + so.additionalValue);
					break;
				case SUBSTRACT:
					question.getOuterParameters().set(so.indexA,
							question.getOuterParameters().get(so.indexB) - so.additionalValue);
					break;
				case MULTIPLY:
					question.getOuterParameters().set(so.indexA,
							question.getOuterParameters().get(so.indexB) * so.additionalValue);
					break;
				case DIVIDE:
					question.getOuterParameters().set(so.indexA,
							question.getOuterParameters().get(so.indexB) / so.additionalValue);
					break;
				case MODULO:
					question.getOuterParameters().set(so.indexA,
							question.getOuterParameters().get(so.indexB) % so.additionalValue);
					break;
				case PREINCREMENT:
					question.getOuterParameters().set(so.indexA, question.getOuterParameters().get(so.indexA) + 1);
					break;
				case PREDECREMENT:
					question.getOuterParameters().set(so.indexA, question.getOuterParameters().get(so.indexA) - 1);
					break;
				case POSTINCREMENT:
					question.getOuterParameters().set(so.indexA, question.getOuterParameters().get(so.indexA) + 1);
					break;
				case POSTDECREMENT:
					question.getOuterParameters().set(so.indexA, question.getOuterParameters().get(so.indexA) - 1);
					break;
				}
			}
		}
		question.setResult(question.getOuterParameters().get(0));
	}

}
