package de.bs.tu.buyuk.ba.ranking.player;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PLAYER")
public class Player implements Comparable<Player> {

	public Player() {

	}

	public Player(String username, String password) {
		this.username = username;
		this.password = password;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(nullable = false, unique = true)
	private String username;
	@Column(nullable = false)
	private String password;
	@Column(nullable = false)
	private boolean groupA;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getGroupA() {
		return groupA;
	}

	public void setGroupA(boolean groupA) {
		this.groupA = groupA;
	}

	@Override
	public int compareTo(Player o) {
		return username.compareTo(o.username);
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Player) {
			Player otherPlayer = (Player) obj;
			return this.username.equals(otherPlayer.getUsername());
		}
		return false;
	}
	
	@Override
	public String toString() {
		return username;
	}
	
}
