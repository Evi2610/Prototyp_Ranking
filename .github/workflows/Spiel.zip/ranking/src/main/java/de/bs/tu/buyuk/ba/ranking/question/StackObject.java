package de.bs.tu.buyuk.ba.ranking.question;

public class StackObject {
	public int indexA;
	public int indexB;
	public EnumOperation operation;
	public int additionalValue;
	
	public StackObject(int indexA, EnumOperation operation, int indexB, int additionalValue) {
		this.indexA = indexA;
		this.operation = operation;
		this.indexB = indexB;
		this.additionalValue = additionalValue;
	}
	
}
