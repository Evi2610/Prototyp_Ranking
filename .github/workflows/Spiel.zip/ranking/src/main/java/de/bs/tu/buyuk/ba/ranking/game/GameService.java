package de.bs.tu.buyuk.ba.ranking.game;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.bs.tu.buyuk.ba.ranking.player.Player;
import de.bs.tu.buyuk.ba.ranking.player.PlayerService;

@Service
public class GameService {

	@Autowired
	GameRepository repository;
	@Autowired
	PlayerService playerService;

	public void createTestData() {
		for (int i = 0; i < 100; i++) {
			Random ran = new Random();
			int target = ran.nextInt(3) + 1;
			for (int j = 0; j < target; j++) {
				Game game = new Game(ran.nextInt(31), playerService.findPlayerByUsername("player" + (i + 1)));
				game.getTimestamp().setSeconds(i % 60);
				repository.save(game);
			}
		}
	}

	public Map<Player, Game> createHighScore() {
		Iterable<Game> gamesIter = repository.findAll();
		Map<Player, Game> player2Game = new HashMap<>();
		gamesIter.forEach(game -> {
			player2Game.putIfAbsent(game.getPlayer(), game);
			if (player2Game.get(game.getPlayer()).getScore() < game.getScore()) {
				player2Game.put(game.getPlayer(), game);
			}
		});
		return player2Game;
	}

	public Game createEmptyGame(Player player) {
		Game game = new Game(0, player);
		game.getTimestamp().setTime(game.getTimestamp().getTime() - (1000 * 60 * 10));
		return repository.save(game);
	}

}
