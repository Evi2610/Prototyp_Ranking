package de.bs.tu.buyuk.ba.ranking.player;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PlayerService {

	private static boolean toggleGroupA = false;

	@Autowired
	private PlayerRepository playerRepository;

	public Player findPlayerById(long id) {
		return playerRepository.findById(id).get();
	}

	public Player findPlayerByUsername(String username) {
		List<Player> players = playerRepository.findByUsername(username);
		if (players.isEmpty()) {
			return null;
		}
		return playerRepository.findByUsername(username).get(0);
	}

	public Player registerPlayer(Player player) {
		if (playerRepository.findByUsername(player.getUsername()).isEmpty()) {
			player.setGroupA(!toggleGroupA);
			toggleGroupA = !toggleGroupA;
			player = playerRepository.save(player);
			return player;
		} else {
			return new Player();
		}

	}

	public Player check(Player player) {
		List<Player> players = playerRepository.findByUsername(player.getUsername());
		if (players.size() == 1) {
			if (players.get(0).getPassword().equals(player.getPassword())) {
				return players.get(0);
			}
		}
		return null;
	}

	public void save(Player player) {
		player.setGroupA(toggleGroupA);
		toggleGroupA = !toggleGroupA;
		playerRepository.save(player);
	}

}
