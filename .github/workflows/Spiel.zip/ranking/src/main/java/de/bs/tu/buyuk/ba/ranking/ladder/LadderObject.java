package de.bs.tu.buyuk.ba.ranking.ladder;


import java.sql.Timestamp;

import de.bs.tu.buyuk.ba.ranking.player.Player;

public class LadderObject implements Comparable<LadderObject> {

	private String player;
	private int score;
	private int rank;
	private Timestamp timestamp;

	public LadderObject(Player player, int score, Timestamp timestamp) {
		this.player = player.getUsername();
		this.score = score;
		this.timestamp = timestamp;
	}

	public String getPlayer() {
		return player;
	}

	public void setPlayer(String player) {
		this.player = player;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	@Override
	public int compareTo(LadderObject o) {
		if (o == null) {
			return -1;
		} else if (this.score > o.score) {
			return -1;
		} else if (this.score < o.score) {
			return 1;
		} else if(this.timestamp.before(o.getTimestamp())) {
			return -1;
		}
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof LadderObject) {
			LadderObject otherLadderObject = (LadderObject) obj;
			return this.getRank() == otherLadderObject.getRank();
		}
		return false;
	}

	@Override
	public String toString() {
		return player + "  " + score;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

}
