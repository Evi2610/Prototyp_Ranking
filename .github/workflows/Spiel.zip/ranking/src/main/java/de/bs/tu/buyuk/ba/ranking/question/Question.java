package de.bs.tu.buyuk.ba.ranking.question;

import java.util.List;
import java.util.Map;

public class Question implements Comparable<Question> {

	private String questionText;
	private Map<String, Integer> possibleAnswers;
	private int level;
	private String[] parameterNames;
	private int[] parameters;
	private List<String> operations;
	private int result;
	private int steps;
	private List<Integer> outerParametersValues;
	private List<EnumParameterName> outerParametersNames;
	private String correctAnswer;

	public Question() {
	}

	public Question(int level) {
		this.level = level;
	}

	public String getQuestionText() {
		return questionText;
	}

	public void setQuestionText(String questionText) {
		this.questionText = questionText;
	}

	public Map<String, Integer> getPossibleAnswers() {
		return possibleAnswers;
	}

	public void setPossibleAnswers(Map<String, Integer> possibleAnswers) {
		this.possibleAnswers = possibleAnswers;
	}

	public boolean checkAnswer(String clicked) {
		return false;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int[] getParameter() {
		return parameters;
	}

	public void setParameter(int[] parameters) {
		this.parameters = parameters;
	}

	public String[] getParameterNames() {
		return parameterNames;
	}

	public void setParameterNames(String[] parameterNames) {
		this.parameterNames = parameterNames;
	}

	public List<String> getOperations() {
		return operations;
	}

	public void setOperations(List<String> operations) {
		this.operations = operations;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Question) {
			Question q2 = (Question) obj;
			return this.questionText.equals(q2.getQuestionText());
		}
		return false;
	}

	@Override
	public int compareTo(Question o) {
		return this.getQuestionText().compareTo(o.questionText);
	}

	@Override
	public String toString() {
		return "\nWas wird auf der Konsole ausgegeben?\n\n" 
	+ getQuestionText() 
	+ "}\n\nSystem.out.println(" + outerParametersNames.get(0) + ");\n\n\n\nA: " 
	+ getPossibleAnswers().get("A") + "\nB: "
	+ getPossibleAnswers().get("B") + "\nC: " 
	+ getPossibleAnswers().get("C") + "\nD: "
				+ getPossibleAnswers().get("D");
	}

	public String getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(String correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public int getSteps() {
		return steps;
	}

	public void setSteps(int steps) {
		this.steps = steps;
	}

	public List<Integer> getOuterParameters() {
		return outerParametersValues;
	}

	public void setOuterParametersValues(List<Integer> outerParameters) {
		this.outerParametersValues = outerParameters;
	}

	public List<EnumParameterName> getOuterParametersNames() {
		return outerParametersNames;
	}

	public void setOuterParametersNames(List<EnumParameterName> outerParametersNames) {
		this.outerParametersNames = outerParametersNames;
	}

}
