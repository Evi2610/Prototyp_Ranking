package de.bs.tu.buyuk.ba.ranking.game;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import de.bs.tu.buyuk.ba.ranking.ladder.LadderService;
import de.bs.tu.buyuk.ba.ranking.player.Player;
import de.bs.tu.buyuk.ba.ranking.player.PlayerService;
import de.bs.tu.buyuk.ba.ranking.question.QuestionBuilder;

@Controller
public class GameController {

	@Autowired
	GameService gameService;

	@Autowired
	PlayerService playerService;

	@Autowired
	LadderService ladderService;

	Map<Long, String> game2CorrectResult;
	List<Game> games;

	public GameController() {
		game2CorrectResult = new HashMap<>();
		games = new ArrayList<>();
	}

	@PostMapping(value = "/", params = "action=Spielen")
	public String getLadderObject(@ModelAttribute Player player, Model model, Game game) {
		if (game.getTimestamp() == null) {
			game = gameService.repository.save(new Game(0, playerService.findPlayerByUsername(player.getUsername())));
		} else if (game.getTimestamp().getTime() < Timestamp.valueOf(LocalDateTime.now()).getTime()) {
			games.remove(game);
			if (player == null) {
				player = game.getPlayer();
			}
			model.addAttribute("player", player);
			if (player.getGroupA()) {
				return ladderService.getLadder(model);
			}
			return ladderService.getLadderObject(model, player);
//			return "login";
		} else {
			game.createQuestion(game.getLevel());
		}
		model.addAttribute("time", (game.getTimestamp().getTime()));
		QuestionBuilder.getINSTANCE().buildQuestion(game.getQuestion());
		model.addAttribute("game", game);
		putResult(game);
		games.add(game);
		return "game";
	}

	public String atGet(String parameter, Game game, Model model) {
		boolean result = checkResult(game.getId(), parameter);
		game = games.get(games.indexOf(game));
		games.remove(game);
		if(result) {
			game.setScore(game.getScore()+1);
		}
		gameService.repository.save(game);
		if (!(Timestamp.valueOf(LocalDateTime.now()).getTime() > game.getTimestamp().getTime() + (1000 * 60 * 10))) {
			if (result) {
				game.setLevel(game.getLevel() + 1);
				game.setTimestamp(new Timestamp(game.getTimestamp().getTime() + (1000 * 30)));
			} else {
				if (game.getLevel() > 1) {
					game.setLevel(game.getLevel() - 1);
				}
				game.setTimestamp(new Timestamp(game.getTimestamp().getTime() - (1000 * 30)));
			}

			return getLadderObject((Player) game.getPlayer(), model, game);
		} else {
			return "login";
		}
	}

	@PostMapping(value = "/", params = "action=A")
	public String getA(@ModelAttribute Game game, Model model) {
		return atGet("A", game, model);
	}

	@PostMapping(value = "/", params = "action=B")
	public String getB(@ModelAttribute Game game, Model model) {
		return atGet("B", game, model);
	}

	@PostMapping(value = "/", params = "action=C")
	public String getC(@ModelAttribute Game game, Model model) {
		return atGet("C", game, model);
	}

	@PostMapping(value = "/", params = "action=D")
	public String getD(@ModelAttribute Game game, Model model) {
		return atGet("D", game, model);
	}

	public void putResult(Game game) {
		game2CorrectResult.put(game.getId(), game.getQuestion().getCorrectAnswer());
	}

	public boolean checkResult(Long game, String answer) {
		return game2CorrectResult.containsKey(game) && game2CorrectResult.get(game).equals(answer);
	}

}
