package de.bs.tu.buyuk.ba.ranking.ladder;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import de.bs.tu.buyuk.ba.ranking.game.Game;
import de.bs.tu.buyuk.ba.ranking.game.GameService;
import de.bs.tu.buyuk.ba.ranking.player.Player;
import de.bs.tu.buyuk.ba.ranking.player.PlayerService;

@Service
public class LadderService {

	@Autowired
	PlayerService playerService;
	@Autowired
	GameService gameService;
	@Autowired
	LadderController ladderController;

	public List<LadderObject> loadAndSortAllPlayers() {
		List<LadderObject> ladder = new ArrayList<>();
		Map<Player, Game> highscores = gameService.createHighScore();
		highscores.forEach((key, value) -> ladder
				.add(new LadderObject(key, value.getScore(), value.getTimestamp())));
		ladder.sort(new Comparator<LadderObject>() {
			public int compare(LadderObject o1, LadderObject o2) {
				return o1.compareTo(o2);
			};
		});
		for (LadderObject l : ladder) {
			l.setRank(ladder.indexOf(l) + 1);
		}
		return ladder;
	}

	public String getLadder(Model model) {
		return ladderController.getLadder(model, loadAndSortAllPlayers());
	}

	public String getLadderObject(Model model, Player player) {
		List<LadderObject> ladder = loadAndSortAllPlayers();
		for (LadderObject o : ladder) {
			if (o.getPlayer().equals(player.getUsername())) {
				model.addAttribute("ladderobject", o);
				return ladderController.getLadderObject(model);
			}
		}
		return "login";
	}

}
