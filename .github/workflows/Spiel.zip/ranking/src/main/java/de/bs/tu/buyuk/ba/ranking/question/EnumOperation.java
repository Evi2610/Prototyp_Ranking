package de.bs.tu.buyuk.ba.ranking.question;

public enum EnumOperation {
	ADD("+"), SUBSTRACT("-"), MULTIPLY("*"), DIVIDE("/"), MODULO("%"), PREINCREMENT("++"), POSTINCREMENT("++"),
	PREDECREMENT("--"), POSTDECREMENT("--");

	private String displayLalbel;

	private EnumOperation(String displayLabel) {
		this.displayLalbel = displayLabel;
	}

	public String getDisplayLabel() {
		return displayLalbel;
	}
}
