package de.bs.tu.buyuk.ba.ranking.player;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import de.bs.tu.buyuk.ba.ranking.maincontroller.ServiceManager;

@Controller
public class PlayerController {

	@Autowired
	PlayerService service;
	@Autowired
	ServiceManager serviceManager;

	@GetMapping("/")
	public String showCreateForm(Model model) {
		Player player = new Player();
		model.addAttribute("player", player);
		return "login";
	}

	private void createTestData() {
		for (int i = 0; i < 100; i++) {
			service.save(new Player("player" + (i + 1), "test"));
		}
	}

	@PostMapping(value = "/", params = "action=Login")
	public String login(@ModelAttribute Player player, Model model) {
		Player dbPlayer = service.check(player);
		if (player.equals(dbPlayer)) {
			model.addAttribute("player", dbPlayer);
			if (dbPlayer.getGroupA()) {
				return serviceManager.getLadderService().getLadder(model);
			} else {
				return serviceManager.getLadderService().getLadderObject(model, dbPlayer);
			}
		} else {
			return "login_wrong";
		}
	}

	@PostMapping(value = "/", params = "action=Register")
	public String register(@ModelAttribute Player player, Model model) {
		if(player.getUsername() == null || player.getUsername().trim().isEmpty()) {
			return "register_wrong";
		}
		player = service.registerPlayer(player);
		model.addAttribute(player);
		if (player.getId() != 0) {
			serviceManager.getGameService().createEmptyGame(player);
			if (player.getGroupA()) {
				serviceManager.getLadderService().getLadder(model);
				return "ladder";
			}
			serviceManager.getLadderService().getLadderObject(model, player);
			return "info";
		} else {
			return "register_wrong";
		}
	}

	@RequestMapping("/createTestData")
	String home(Model model) {
		createTestData();
		serviceManager.getGameService().createTestData();
		return showCreateForm(model);
	}

}
