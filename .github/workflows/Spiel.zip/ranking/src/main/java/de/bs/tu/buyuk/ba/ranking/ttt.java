package de.bs.tu.buyuk.ba.ranking;

public class ttt {

	public static void main(String[] args) {
		int a = 0;

		for( int k = 0; k <= 24; k++) {
			a = a%3;
			a = a%2;
		}

		System.out.println(a);

	}

}
