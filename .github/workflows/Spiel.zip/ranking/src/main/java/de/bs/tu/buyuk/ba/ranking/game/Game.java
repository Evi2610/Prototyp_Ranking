package de.bs.tu.buyuk.ba.ranking.game;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import de.bs.tu.buyuk.ba.ranking.player.Player;
import de.bs.tu.buyuk.ba.ranking.question.Question;
import de.bs.tu.buyuk.ba.ranking.question.QuestionBuilder;

@Entity
@Table(name = "GAME")
public class Game implements Comparable<Game> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(nullable = false)
	private int score;

	@Column(nullable = false)
	private Timestamp timestamp;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "player.id")
	private Player player;

	@Transient
	private Question question;

	@Transient
	private String questionString;

	@Transient
	private int level;

	public Game() {

	};

	public Game(int score, Player player) {
		this.score = score;
		this.player = player;
		this.timestamp = Timestamp.valueOf(LocalDateTime.now());
		this.timestamp.setTime(this.getTimestamp().getTime() + (1000 * 60 * 10));
		level = 1;
		question = new Question(level);
		QuestionBuilder.getINSTANCE().buildQuestion(question);
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	@Override
	public int compareTo(Game o) {
		if (o == null) {
			return 1;
		} else if (this.score > o.score) {
			return 1;
		} else if (this.score < o.score) {
			return -1;
		}
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Game) {
			Game otherGame = (Game) obj;
			return this.getId() == otherGame.getId();
		}
		return false;
	}

	@Override
	public String toString() {
		return player + " score: " + getScore() + " gespielt: " + getTimestamp();
	}

	public String getText() {
		return getQuestion().toString();
	}

	public void createQuestion(int level) {
		question = new Question(level);
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getQuestionString() {
		return questionString;
	}

	public void setQuestionString(String questionString) {
		this.questionString = questionString;
	}

	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}
}
