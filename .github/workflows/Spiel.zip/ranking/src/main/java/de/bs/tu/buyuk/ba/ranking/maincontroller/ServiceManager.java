package de.bs.tu.buyuk.ba.ranking.maincontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.bs.tu.buyuk.ba.ranking.game.GameService;
import de.bs.tu.buyuk.ba.ranking.ladder.LadderService;
import de.bs.tu.buyuk.ba.ranking.player.PlayerService;

@Service
public class ServiceManager {

	@Autowired
	private PlayerService playerService;
	@Autowired
	private LadderService ladderService;
	@Autowired
	private GameService gameService;

	public PlayerService getPlayerService() {
		return playerService;
	}

	public GameService getGameService() {
		return gameService;
	}

	public LadderService getLadderService() {
		return ladderService;
	}
}
