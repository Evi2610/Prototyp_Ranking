package de.bs.tu.buyuk.ba.ranking.ladder;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LadderController {

	@GetMapping("/ladder")
	public String getLadder(Model model, List<LadderObject> ladder) {
		model.addAttribute("ladderobjects", ladder);
		return "ladder";
	}

	@GetMapping("/info")
	public String getLadderObject(Model model) {
		return "info";
	}
}