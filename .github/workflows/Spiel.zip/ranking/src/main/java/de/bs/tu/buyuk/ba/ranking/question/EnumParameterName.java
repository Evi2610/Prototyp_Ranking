package de.bs.tu.buyuk.ba.ranking.question;

public enum EnumParameterName {
a,b,c,d,e,r,s,t,u,v,w,x,y,z;
}
